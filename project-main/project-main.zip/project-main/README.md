# Backrooms Lobby (prototype)

Lobby 3D horror bergaya Backrooms: Next.js 14 + TypeScript + Three.js + @pixiv/three-vrm. Tanpa env var, aplikasi tetap jalan sebagai Single Player/Guest offline; login & multiplayer online aktif setelah Firebase + Supabase dikonfigurasi (lihat **docs/BACKEND_SETUP.md** dan `.env.example`).

```
npm install
npm run dev     # http://localhost:3000
npm run build   # build produksi (siap Vercel: import repo, framework Next.js, tanpa setting tambahan)
```

## Catatan
- Karakter default = model James (`public/models/james.glb`). Untuk mengganti default, timpa file itu dengan model lain (.glb embedded). Pemain bisa upload karakter sendiri lewat tombol Karakter; tombol "Kembali ke default" memuat James lagi.
- Model James tidak punya tulang, jadi dipasangi kerangka humanoid + skin otomatis saat dimuat (`lib/3d/rigcore.ts`, `autorig.ts`). Animasi jalan, lari, lompat, jongkok, idle dibuat prosedural di `lib/3d/motion.ts`. Tombol Jalan/Lari/Lompat/Jongkok di pojok kiri bawah lobby; tanpa ditekan, karakter bergerak sendiri secara acak. Model statis lain yang diupload juga di-rig otomatis; model ber-rig (Mixamo/VRM) memakai animasinya sendiri.
- UID: 5 digit acak, dibuat otomatis sekali per perangkat/browser dan disimpan di localStorage (tidak bisa diedit). Tidak bentrok dengan UID demo.
- Teman/invite/party memakai MOCK USER lokal (UID demo 12345, 23456, 34567, 45678). Data di localStorage/IndexedDB perangkat ini saja. TIDAK real-time antar perangkat. Tombol DEMO mensimulasikan sisi teman. Karena belum ada backend, UID acak belum bisa dicari perangkat lain.
- Untuk backend nanti: ganti fungsi di `lib/social/logic.ts` dengan API/WebSocket.
- Model upload: .glb / .gltf (embedded) / .vrm, maks 40 MB. Clip animasi dipakai bila ada (idle/walk); jika tidak, idle prosedural + lengan diturunkan dari T-pose.
- Foto profil diperkecil otomatis (WEBP) sebelum disimpan di IndexedDB. Fitur upload background sudah dihapus; latar selalu ruang Backrooms.
- Struktur: `lib/3d` (renderer, karakter), `lib/storage`, `lib/social`, `components/*`.

## Kredit
- Model default "James realistic male character 3D model" oleh StormierTunic16 (https://sketchfab.com/jondavila98), lisensi CC BY 4.0. Tekstur dikecilkan ke 2048 px agar ringan di HP; geometri tidak diubah.

## Game Backrooms (map GLB)
- Map: `public/models/backrooms_full.glb`. Dimuat di `components/lobby/PlayScene.tsx` lewat `lib/game/world.ts`. Collision dari mesh dinding map + kotak furniture.
- Semua angka yang bisa diubah ada di `lib/game/config.ts` (seed, jumlah furniture, battery, stamina, event, audio, lighting).
- **Key & exit**: 3 key berwarna (Yellow/Red/Green, `lib/game/keys.ts`) tersembunyi di dalam container (laci, lemari, locker, crate, box). Cari container (SEARCH) -> key muncul di dalam container terbuka -> bidik dengan crosshair `+` -> `PICK UP` -> masuk inventory dan hilang dari world. Exit punya rantai + 3 gembok berwarna; tiap gembok hanya terbuka oleh key dengan warna/ID yang sama (bukan sekadar jumlah). Setelah ketiganya terbuka, rantai lepas dan pintu exit terbuka.
- **Furniture**: semua laci, lemari, locker, peti, dan kotak bisa dibuka lalu ditutup lagi (tombol Interaksi / E). Pertama kali dibuka = menggeledah (isi muncul sekali); sesudahnya buka-tutup bebas. Tiap jenis punya SFX buka/tutup sendiri (drawer, cabinet, locker, lid). Key yang belum diambil ikut tersembunyi saat container ditutup.
- **Landscape**: game langsung tampil landscape tanpa layar blokir. Screen Orientation API + fullscreen dicoba saat klik Play (enhancement). Bila ditolak dan HP masih portrait, fallback CSS (`html.rotfix`, dipasang script di `app/layout.tsx`) memutar seluruh UI 90° sehingga canvas/joystick/tombol tetap landscape; koordinat sentuh dipetakan di `PlayScene`. Tombol Demo di lobby hanya muncul saat development.
- **Kontrol mobile**: analog kiri (jalan), geser kanan (lihat), tombol floating transparan di kanan bawah (Interaksi, Senter, Lari, Jongkok; tanpa teks). Lari otomatis lepas saat berhenti.
- **Senter (F / tombol senter)**: SpotLight mengikuti POV. Battery 2 menit pemakaian terus-menerus (`FLASH_MAX_SECONDS`), persen tampil di HUD, berkurang hanya saat ON, mati otomatis saat habis. Pemain mulai dengan 1 battery di inventory; battery tambahan ada di furniture (minimal `MIN_BATTERY_PICKUPS` per run). Pakai battery dari inventory = recharge 100%. Cahaya ambient sengaja kecil: area berlampu terang karena lampu map, area tanpa lampu gelap.
- **Sprint & stamina**: tombol lari / Shift. Jongkok (C / tombol jongkok): kamera & collider turun, lebih lambat, langkah lebih pelan; tidak bisa berdiri bila ruang terlalu sempit. Stamina turun saat lari, pulih saat tidak lari (ada jeda), tidak bisa sprint saat habis sampai pulih ke `STAMINA_RESUME_AT`.
- **Event horor acak** (`lib/game/events.ts`, efek di `world.ts`): lampu mati-nyala, pintu terbuka sendiri lalu menutup, furniture bergeser, bayangan melintas. Jarang (45-120 dtk), jenis tidak berulang berurutan, dan selalu divalidasi aman: tidak menutup jalan/key/container/exit (flood-fill ulang), tidak menjebak pemain di pintu, container berisi key tidak pernah dipindah, bayangan tanpa collision.
- **Seed**: `MAP_SEED = null` -> seed baru tiap mulai/restart. Seed menentukan furniture, posisi tiap key, isi container, serta jadwal & jenis event. Isi angka untuk layout yang selalu sama.
- **Audio** (`lib/game/audio.ts`, `lib/game/sfx.ts`): WebAudio, SFX posisional (atenuasi linear, panner equalpower), pitch & varian acak, maksimal `MAX_VOICES` suara bersamaan, throttle per jenis, langkah kaki & ambience pelan. Tiap event punya SFX sendiri (lights_off/on, door_open/close, furniture_scrape, entity_steps+whisper).
- **File SFX** di `public/sfx/*.wav` disintesis sendiri oleh `scripts/gen-sfx.py` (noise + osilator; tanpa sample pihak ketiga, jadi bebas masalah lisensi). Ganti dengan rekaman CC0 favoritmu dengan nama file yang sama bila mau; jalankan ulang generator dengan `npm run gen:sfx` (butuh python3 + numpy + scipy).
- Bidikan key: furniture pemilik key tidak menghalangi crosshair, tetapi dinding/objek lain tetap menghalangi (tidak bisa interaksi menembus). Raycast dibatasi ~20 Hz dan dilewati saat kamera diam.
- HUD senter & stamina ditulis langsung ke DOM (tanpa render ulang React per frame).
- Resolusi render adaptif: turun otomatis bila FPS rendah di HP, naik lagi bila lancar.
- Inventory per pemain (`lib/game/inventory.ts`). Tes logika dengan GLB asli: `npm run test:game`.

## Anti-softlock
- Tiap run divalidasi sebelum dimulai: 3 key (Yellow/Red/Green) ada di 3 container berbeda yang bisa dibuka, terjangkau, posisinya di atas lantai & di dalam map (bukan di dinding); exit terjangkau dari spawn; spawn tidak menabrak apa pun.
- Bila gagal: key dipilih ulang dari container valid, lalu seed turunan (maks 6 percobaan), dan percobaan terakhir memakai layout bawaan map tanpa furniture acak. Tidak ada loop tanpa batas dan tidak crash.
- Spawn yang tidak aman otomatis digeser ke titik aman terdekat.
- Tes: `npm run test:game` (600 seed + kasus rusak yang disengaja).

## Environmental storytelling (dekor ringan)
- `lib/game/decor.ts` (logika murni, dites) + `GameWorld.buildDecor` di `world.ts`. Angka di `config.ts` (`DECOR_ENABLED`, `DECOR_COUNTS`, `DECOR_MIN_GAP`).
- Per run (RNG turunan seed, tidak mengubah urutan RNG furniture/key/event): ~45-65 instance kertas, noda, kardus, kaleng/ember, kabel, pipa, ventilasi, APAR, rambu peringatan, rambu EXIT kecil di atas pintu biasa.
- Reuse aset map: noda `Decal_Stain`, kardus `Box_Util`, pipa `Pipe_Util`, rambu `Exit_Sign`, material `M_Dirt/M_Cardboard/M_MetalDark/M_ExitSign`. Hanya kertas, APAR, rambu peringatan, kaleng, ventilasi yang geometri kecil baru (tanpa tekstur/dependency).
- Aman: tanpa collision & tidak ikut raycast; menjauhi spawn/exit/tangga/pintu; kardus/benda kecil hanya di jalur sempit antara dinding dan area jalan pemain (tidak pernah di sel yang bisa dijalani) dan jauh dari furniture; benda dinding menempel di permukaan dinding asli. Path, key, exit, spawn tidak disentuh.
- Performa: 1 InstancedMesh per jenis (maks ~9 draw call), dihitung sekali per run, nol biaya per frame, dibuang & dibuat ulang saat restart, dispose saat unmount.

## Variasi kondisi ruangan per seed
- `lib/game/roomstate.ts` (logika murni, dites) + `GameWorld.initialShifts/applyRoomState`. Angka di `config.ts` (`ROOM_STATE_ENABLED`, `ROOM_STATE`). Memakai RNG turunan dari seed run (seed sama -> kondisi sama; urutan RNG furniture/key/event tidak berubah).
- Variasi: 1-3 furniture acak bergeser sejak awal; 2-4 pintu biasa terbuka; 3-5 lampu redup/berkedip; 2-4 container KOSONG sudah terbuka; jumlah dekor (kertas, noda, kardus, kabel, ventilasi) bervariasi.
- Aman: pergeseran memakai validasi yang sama dengan event furniture (`planShift`: flood-fill, titik wajib, akses container, keepout). Container berisi key/loot tidak pernah dibuka duluan. Pintu locked/exit tidak disentuh. Area sekitar spawn dan exit tetap terang & bersih (pintu >= 3.5 m dari spawn, lampu >= 7 m dari spawn/exit).

## Map utama: backrooms_full.glb
- Skema map dibaca di `lib/game/mapdata.ts` (`normalizeMap` + `extractMapData`): spawn lantai 1, exit `Door_24` (3 gembok warna), tangga A (dijalani langsung, lihat bagian Polish interaksi), 266 container (laci/lemari/locker/kulkas) dari furniture bawaan, 295 collider furniture, lantai 2 (`LEVEL_Y` di config).
- Kunci/kode bawaan map untuk pintu non-exit diabaikan (pintu biasa); exit lantai 2 tersegel permanen. Ruang rahasia tersegel (Hidden2, Vault) tidak dipakai.
- Furniture acak = salinan furniture bawaan (`TEMPLATE` di world.ts). Mesh statis digabung (batching) saat load untuk mengurangi draw call di HP.


## Polish interaksi, pintu, furniture & tangga
- **Tangga** (`lib/game/stairs.ts`): tidak ada teleport/CLIMB. Pemain berjalan masuk lewat mulut tangga (kaki di lantai 1, ujung atas di lantai 2), tinggi kaki mengikuti anak tangga (`PlayerState.y`, kamera diinterpolasi), dinding samping menahan, badan tangga padat dari sisi & kolong. Naik dan turun memakai logika yang sama; kecepatan x0,8, bob kamera lebih kuat, langkah lebih rapat (SFX langkah keras; tidak ada SFX tangga khusus).
- **Pintu** (`lib/game/door.ts`): engsel = origin node pintu; daun berayun dengan easing halus. Collision mengikuti pose daun selama sudut < 70% (terbuka cukup lebar = non-blocking), tidak menembus pemain (daun berhenti sampai pemain menyingkir), tidak pernah menjebak (collision menunggu pemain keluar dari ambang). Jangkauan 2,0 m.
- **Container** (`lib/game/swing.ts`): bukaan dibatasi bila akan menembus dinding/furniture lain (`openLimit`, dihitung ulang tiap run & setelah furniture bergeser; container yang terlalu sempit tidak dipakai untuk key). Laci/pintu yang terbuka penuh punya collision sesuai pose (aktif hanya saat pemain tidak tumpang tindih). Interaksi container ditolak bila garis ke target menembus dinding.
- **Placement**: keepout ditambah area ayunan semua pintu + seluruh ruang tangga; `auditPlacements` memeriksa ulang tiap run (dinding, furniture lain, area bebas) dan menolak run yang gagal.
- Tes: `npm run test:game` (termasuk `scripts/test-polish.js`).


## Perbaikan akar masalah: pintu / locker / laci / lemari tidak bisa dibuka (video bug part 1-3)
- **Penyebab**: `GameWorld.build` memetakan node glTF -> objek three lewat `gltf.parser.associations`. Di three 0.164.1, klon mesh yang berbagi geometri memakai SATU objek asosiasi, sehingga hanya node terakhir per grup mesh yang terpetakan. Di map ini 538 dari 540 node interaktif berbagi mesh (semua `Door_NN`, `Locker_NN`, `Drawer_NN`, lemari, kulkas), jadi hampir semuanya tidak punya objek three: tidak terdaftar ke raycast ("Tidak ada yang bisa dilakukan"), tidak beranimasi, dan `Door_24` (exit) tidak pernah membuka walau tampil "EXIT OPEN".
- **Perbaikan**: pemetaan lewat NAMA node (`indexNodesByName` di `mapdata.ts`, nama unik), bukan `associations`. Satu sistem existing dipakai ulang; tidak ada sistem baru untuk pintu/container.
- **Tambahan**: tutup ventilasi (8 flap, 4 ventilasi) dan tuas generator kini interaktif lewat `FlapRT` kecil (easing, SFX, reset tiap run, tanpa raycast/state React per frame).
- **Uji**: `npm run test:game` (3183 + 37 pemeriksaan, termasuk regresi pemetaan semua node interaktif) dan `npm run audit:map` (overlap furniture bawaan vs dinding/antar furniture).


## Fitur baru: sembunyi, kasur, detak jantung & napas kelelahan
- **Kasur** (`generateBeds` di `layout.ts`, model prosedural di `GameWorld.buildBed`): 3 kasur per run (2 di ruang istirahat, 1 di ruang lain), kepala menempel dinding, divalidasi seperti furniture (tidak menimpa dinding/furniture, tidak menutup pintu/jalur utama/spawn/tangga, tidak membuat celah jebakan, RNG terpisah sehingga seed furniture tidak berubah). Bidik kasur lalu tekan interaksi / tombol HIDE: karakter merangkak ke kolong, layar tertutup bawah-kasur dengan garis pandang rendah, menoleh dibatasi. Tekan lagi untuk keluar dari sisi masuk.
- **Locker & lemari** (semua `Locker` dan `Cabinet`, bawaan map maupun acak): bidik lalu tekan tombol HIDE (atau `H`). Urutan: pintu terbuka -> masuk -> pintu menutup -> masker celah ventilasi horizontal untuk mengintip. Tombol interaksi / HIDE untuk keluar (pintu terbuka lagi, karakter keluar ke depan; bila jalan keluar terhalang muncul BLOCKED). Senter otomatis mati selama bersembunyi lalu kembali seperti semula.
- **Detak jantung**: SFX baru (`heartbeat.wav`, lub-dub dengan dentuman dada), tempo & volume naik saat stamina menipis dan paling cepat saat habis.
- **Napas kelelahan**: `pant.wav` berulang selama stamina habis (selain `breath.wav` saat baru habis). `rustle.wav` untuk merangkak.
- Semua SFX dibuat prosedural oleh `python3 scripts/gen-body-sfx.py` (numpy saja, bebas lisensi). Uji: `npm run test:game` (termasuk `scripts/test-hide.js`: penempatan kasur 200 seed).

## Kursi custom (chair.glb)
- Semua kursi bawaan map (node `extras.type = "Chair"`, 38 buah) diganti model `public/models/chair.glb` saat load (`GameWorld.swapChairs` di `world.ts`, URL di `config.ts` -> `CHAIR_URL`). File map tidak diubah; bila `chair.glb` hilang/rusak, kursi bawaan map dipakai otomatis.
- **Anti-tembus**: collision kursi TIDAK diganti. Model diskalakan seragam (`lib/game/chairfit.ts`) agar footprint-nya selalu di dalam kotak collision kursi bawaan (0,5 x 0,5 m) dan tingginya 1,03 m; pivot di tengah, kaki di lantai, sandaran di belakang (-Z lokal) seperti kursi lama. Jadi pemain tidak bisa masuk ke bagian kursi mana pun.
- Performa HP: 1 geometri + 1 material untuk semua kursi, ikut batching statis (`batchStatic`). Tekstur chair.glb diperkecil 1024 -> 512 px (geometri tidak diubah), 2,4 MB -> 0,7 MB.
- Uji: `npm run test:game` (termasuk `scripts/test-chair.js`: footprint di dalam kotak collision untuk 38 kursi, orientasi, dan ~9.700 gerakan pemain dari 24 arah memakai fungsi gerak game asli).

## Opening: bangun setelah pingsan
- Sekali saat pertama masuk game (tidak diulang saat "Main lagi"), ~7,5 detik: layar hampir hitam -> terbuka perlahan, blur + vignette kuat yang turun bertahap, kepala sedikit goyah/miring (maks ~6 derajat, hanya visual), suara teredam -> jernih, napas & detak jantung samar, jalan/bidik awalnya lambat lalu kembali 100% normal. Tidak ada jumpscare.
- Memakai sistem yang sudah ada: kamera & loop `PlayScene`, `AudioManager` (`setMuffle` = low-pass di rantai master + sfx `breath`/`heartbeat`), dan `.vignette` (lewat variabel CSS `--vg/--vs`). Logika waktu murni di `lib/game/opening.ts`.
- Matikan/atur di `config.ts`: `OPENING_ENABLED`, `OPENING_SECONDS`, `OPENING_BLUR_PX`, `MUFFLE_MIN_HZ`. `prefers-reduced-motion` = tanpa goyang kamera & blur separuh.
- Uji: `scripts/test-opening.js` (dijalankan oleh `npm run test:game`).

## SFX dari repo Sound (file mp3)
- Repo `kenza11-star/Sound` (folder `Lacidrawer`, `Lemaricabinet`, `Loker`, `Tanggalantai`: 14 file; 11 identik dengan file yang sudah dipakai, 3 baru) + 8 file mp3 tambahan = 22 mp3 di `public/sfx/` (file asli tidak diubah). `Tanggalantai/Walk.mp3` & `Run.mp3` disimpan sebagai `Tanggalantai_Walk.mp3` / `Tanggalantai_Run.mp3`. File yang muncul ganda di repo (`metal-door-open-02`, `metal-door-unlock-02` ada di `Lacidrawer` dan `Loker`; `wooden drawer close` = `growth-...part-1`; `metal locker creak` = `metal_locker_creak`) cukup satu salinan.
- `lib/game/sfxclips.ts` (DIHASILKAN oleh `python3 scripts/gen-sfx-clips.py`, butuh ffmpeg+numpy+scipy) berisi potongan: waktu tiap langkah/benturan, gain (puncak -2 dBFS seperti SFX lama), fade, dan `hit` (momen benturan). `AudioManager` men-decode tiap file sekali, mengiris potongannya (mono, gain/fade dibakar, pembatas lembut) lalu membuang buffer besarnya -> cache kecil (~9 MB) dan tanpa delay saat dimainkan. File .wav lama tetap ada dan otomatis dipakai bila mp3 gagal dimuat (`legacy`).
- Pemetaan: jalan = walking-on-concrete + `Walk.mp3` (16 varian); lari = soumages-running + `Run.mp3` (21 varian); tangga = footsteps-stairs-slow + concrete-footsteps-6752 (22 varian); napas berat = heavy-breathing; detak jantung = heartbeat ("lub-dub"); pintu buka = door-creak (animasi buka diperlambat ~2,4 dtk, `DOOR_OPEN_SLOW`), tutup = door-close-effect (~0,6 dtk); event horor acak (`slam` di events.ts/world.ts) = door-slam & impact-slam; decit lantai = floorboard-creak (jarang saat berjalan + variasi suara jauh); laci buka = desk-drawer-open-02 / desk-drawer-slide-02 (berhenti dengan ketukan lembut), laci tutup = growth (`wooden drawer close`) / desk-drawer-slide-01 (benturan keras di ujung); lemari buka = refrigerator-door-open-02, tutup = door-close-47; loker buka = metal-door-open-02, tutup = metal locker creak (berderit lalu klang), kunci metal = metal-door-unlock-02.
- Varian dipilih acak tanpa mengulang file yang sama berturut-turut. Furniture memutar SFX di posisi objek yang berinteraksi; `PlayOpts.sync` menunda suara agar benturan/kunci jatuh tepat saat animasi berhenti. Cadence langkah = kecepatan / panjang langkah (`STRIDE_*` di config.ts): jalan ~1,8/dtk, lari ~3,3/dtk, jongkok ~1,5/dtk; volume jalan 1x, lari 1,5x, jongkok 0,35x.
- Uji: `scripts/test-sfx.js` (dalam `npm run test:game`).

## Soda NORVIX (menggantikan Almond Water)
- Item `almond_water` kini `soda` (label **Soda**, bisa dipakai dari inventory). Model: `public/models/NORVIX_SODA_330ML_1file_vertexcolor.glb` (`SODA_URL` di config). Material & vertex color GLB dipertahankan (hanya ditambah pantulan lingkungan pada logam); ukuran asli 11,5 cm, pivot di dasar, tanpa scale/float/putar.
- Penempatan (`lib/game/soda.ts`, di `GameWorld.placeSodas`): titik `ItemSpawn` bawaan map (meja/meja kerja/resepsionis, papan rak StorageShelf), permukaan meja & meja kerja acak, dan di dalam laci/lemari lewat isi container (`spawnSodaIn`: tinggi dasar dicari dengan raycast ke permukaan container). Tidak ada soda di lantai. Meja acak yang membawa soda tidak ikut digeser event furniture.
- Pickup memakai sistem yang sama (crosshair + PICK UP -> inventory). Model 112 rb vertex hanya digambar dalam `SODA_CULL_DIST` dan tidak ikut raycast/shadow (area bidik = proxy kecil).
- Uji: `scripts/test-soda.js` memeriksa 122 titik bawaan terhadap geometri GLB map asli (selisih permukaan 0 mm, alas tertopang, ruang bebas).

## SCP-106 jumpscare (khusus locker & lemari)
- Model: `public/models/scp-106.glb` (`SCP_URL`). GLB punya skeleton tapi tanpa animasi; pose & gerak dibuat dari rotasi tulang (`lib/game/scp106.ts`): lengan terangkat ke depan & terbuka, lalu menutup memeluk; badan/kepala condong ke pemain.
- Pemicu: saat `generate()` tiap run, 5-12 locker/lemari (Locker & Cabinet yang bisa dibuka & terjangkau) dipilih acak dari seed (`SCARE_PICK_*`); tidak pernah semuanya. Dihubungkan ke `toggleContainer` (event buka container asli). Tiap lokasi terpilih memicu sekali per run; yang lain normal. Tidak aktif saat bersembunyi (H).
- SCP muncul di dalam locker, menerjang ke arah pemain, ~1,25 dtk, lalu hilang seketika dan dilepas dari scene.
- Efek (`lib/game/scarefx.ts`, di `PlayScene`): kecepatan x0,35 tepat 1,5 dtk, blur CSS filter pada canvas (seperti opening) yang pulih halus; tidak menumpuk (trigger saat aktif ditolak; dengan opening dipakai yang terkuat). Tanpa efek ke HP/kontrol/sensitivitas. Dibersihkan saat restart & unmount. Atur di `config.ts` (`SCARE_*`).
- Uji: `scripts/test-scare.js`.


## Loading screen, login/register & mode pemain (tahap UI; backend belum ada)
- **Loading screen** (`components/ui/LoadingScreen.tsx`, latar `HorrorBackdrop.tsx`, gaya `app/horror.css`): teks hanya "Loading..." (tanpa persen/status/bar). Tampil dari awal sampai pemuatan nyata selesai: (1) kode Lobby diunduh (`app/page.tsx`), (2) font + karakter lobby selesai dimuat (`Lobby.tsx`: `stageReady && fontsReady`), (3) saat klik Play sampai `GameWorld.load` selesai (`PlayScene.tsx`, `status === 'loading'`). Tidak ada timer buatan; transisi 900 ms lama "MEMASUKI THE BACKROOMS..." dihapus. Satu-satunya batas waktu: font horror gagal diunduh (offline) dilepas setelah 1,5 dtk agar tidak menahan (`lib/ui/fonts.ts`), dan berjalan paralel dengan pemuatan lain.
- **Login/Register** (`components/auth/AuthScreen.tsx`): font horror (Eater + Special Elite via Google Fonts, fallback serif/monospace bila offline), jaring laba-laba SVG bergoyang pelan, kabut, kedip gelap; hanya animasi transform/opacity. Responsif: HP landscape memakai layout dua kolom lewat container query (ikut benar saat UI diputar `.rotfix`), target sentuh >= 42 px, input 16 px (tanpa zoom iOS).
  - Validasi bentuk input saja (`lib/auth/validate.ts`, dites `scripts/test-auth.js`). **Bukan keamanan**: hash password, cek duplikat, rate limit, sesi harus di backend.
  - Semua panggilan lewat `AuthProvider` (`lib/auth/types.ts`). **Titik integrasi backend = `lib/auth/provider.ts`** (contoh ada di komentar). Saat ini provider `available:false`: form tervalidasi lalu menampilkan pesan jujur "server akun belum tersambung"; tidak ada akun/password disimpan di perangkat, password dikosongkan dari state setelah dikirim.
  - "Play as Guest" = jalur offline yang benar-benar berjalan (profil lokal seperti sebelumnya). Tombol "Masuk / Daftar" di lobby membuka kembali menu ini.
- **Mode pemain** (`lib/game/players.ts`, `components/lobby/PlayerModeModal.tsx`): Single Player / 2 / 3 / 4 Players. Disimpan di localStorage (`bl:playerMode`; data lama 'duo' dimigrasi ke 2 Players) dan diterapkan ke `PlayScene` lewat daftar slot (`buildSlots`): jumlah slot, titik spawn per slot (`GameWorld.spawnPoints`: slot 0 selalu tepat di spawn asli, slot lain di sekitarnya, bebas collision), pembagian layar kamera per slot (`view`, disiapkan untuk split-screen/spectate), dan `PlayerState` per slot terisi. Konstanta di `config.ts` (`PLAYER_MODE_DEFAULT`, `MAX_PLAYERS`, `SPAWN_SPREAD`, `SPAWN_MIN_GAP`).
  - **Belum ada networking**: hanya slot 0 (pemain lokal) yang bisa dimainkan. Slot lain kosong (atau anggota party mock lokal yang tidak disimulasikan). Memulai mode 2-4 dengan slot kosong meminta konfirmasi yang menjelaskan hal ini; HUD menampilkan "N PLAYERS · x/N slot · offline".
- Tes: `npm run test:game` (menambah `test-players.js` & `run-test-ui.sh`). Catatan: assertion "semua file SFX ada" di `test-game.js` sudah gagal sebelum perubahan ini (memeriksa `.wav` untuk SFX yang kini berupa `.mp3`).

### Landscape asli di HP (update)
- Sentuhan pertama di lobby/menu login meminta fullscreen + `orientation.lock('landscape')` (`Lobby.tsx`); bila berhasil, layar benar-benar landscape (keyboard tidak miring) dan fallback CSS `.rotfix` otomatis mati. `public/manifest.webmanifest` (`display: fullscreen`, `orientation: landscape`) membuat landscape terkunci sejak awal bila game di-"Install app / Tambahkan ke layar utama" dari Chrome. Browser yang menolak lock (mis. iOS Safari) tetap memakai fallback CSS.
- Email dihapus dari login/register: hanya username + password.

## Pause menu (tombol menu di pojok kanan atas, menggantikan X)
- Tombol kanan-atas sekarang membuka menu (ikon ☰). Keyboard `Esc` membuka/menutup menu (dari sub-panel = kembali ke menu utama; dari konfirmasi keluar = batal). Di luar status bermain (loading/error/escaped) `Esc` tetap keluar seperti sebelumnya.
- **Single Player = freeze penuh.** Selama menu terbuka `PlayScene` hanya merender ulang frame terakhir: `world.update` tidak dipanggil (musuh/SCP, event horor, timer tertunda, pintu/laci, lampu), gerak/physics, senter, stamina, efek opening/jumpscare tidak maju, dan audio di-suspend. Waktu dunia (`GameWorld.clock`) hanya bertambah lewat `dt`, jadi tidak ada lonjakan waktu setelah RESUME dan progres tidak tersentuh. OPTIONS tidak mereset apa pun.
- **Multiplayer (mode 2-4 slot) = overlay lokal.** Menu hanya menutupi layar lokal: dunia, musuh/SCP, timer, dan simulasi tetap berjalan, audio dunia tetap hidup. Input lokal (stick, bidik, tombol aksi, keyboard gameplay) dimatikan, tetapi pemain tetap berada di dunia (senter tetap terkuras, bahaya tetap bisa mengenainya). RESUME mengembalikan kontrol. Tidak ada pause global. **Catatan:** proyek belum punya networking; kebijakan ini sudah dipasang pada jumlah slot (`roster.length > 1`) sehingga langsung berlaku saat networking ditambahkan.
- Isi menu: RESUME, OPTIONS (grafik LOW/MEDIUM/HIGH = batas resolusi render + shadow senter; sensitivitas bidik 0.4-2.5x; volume master; invert Y), PLAYERS (daftar slot + status koneksi: LOCAL / NOT CONNECTED / WAITING), HOW TO PLAY (kontrol mobile & PC), LEAVE GAME (dialog konfirmasi sebelum keluar ke lobby). Pengaturan disimpan di `localStorage` (`bl:settings`), default = perilaku game sebelumnya.
- Aman: saat menu dibuka/ditutup stick, tombol keyboard, dan pointer bidik direset (tidak ada input yang nyangkut); sentuhan di overlay tidak sampai ke canvas/tombol gameplay; menu otomatis tertutup bila status berubah (escaped/error) atau saat restart.
- File: `lib/game/pause.ts` (logika murni), `lib/game/settings.ts`, `components/lobby/PauseMenu.tsx`, integrasi di `PlayScene.tsx` (gate frame di loop), gaya `.pz-*` di `app/horror.css`, `AudioManager.setVolume`. Uji: `scripts/test-pause.js` (masuk `npm run test:game`).


## Update: lobby responsif, karakter terkunci, persiapan multiplayer online
- **Lobby responsif**: layout portrait (profil kiri atas, teman kanan atas, tombol mode + PLAY selebar layar di bawah), landscape HP, dan PC. Fallback putar-layar `.rotfix` HANYA aktif saat bermain (`html[data-play]`, diatur `lib/ui/playmode.ts`); lobby & login tidak pernah diputar. Fullscreen + kunci landscape hanya diminta saat menekan Play dan dilepas saat kembali ke lobby.
- **Karakter terkunci** (`lib/character/config.ts`): tombol KARAKTER membuka modal `COMING SOON`. Semua pemain, lokal maupun remote, memakai model default yang sama; model tersimpan diabaikan (tidak dihapus). Ubah `CHARACTER_SELECTION_ENABLED` ke `true` untuk mengaktifkan lagi tanpa merombak sistem.
- **Multiplayer (maks 4 pemain)**: `lib/net/*` (protokol tervalidasi, interpolasi, `RoomClient`, transport Supabase) + `lib/3d/RemotePlayers.ts` (satu instance model per pemain: posisi, rotasi, nama, animasi sendiri) + `PlayScene` (`net` prop). Pause menu multiplayer = overlay lokal; pengiriman posisi memakai timer sendiri sehingga tidak berhenti saat menu dibuka. Single Player tetap freeze penuh.
- **Backend**: Firebase Auth (`lib/auth/firebaseProvider.ts`), API Vercel (`app/api/*`, verifikasi token di server), skema Supabase + RLS (`supabase/schema.sql`). Env: `.env.example`, penjelasan di `docs/BACKEND_SETUP.md`.
- Tes tambahan: `npm run test:net`, `npm run test:backend`, `npm run check:secrets`, `npm run test:sql` (butuh Postgres lokal, lihat header `scripts/test-sql.sh`).
