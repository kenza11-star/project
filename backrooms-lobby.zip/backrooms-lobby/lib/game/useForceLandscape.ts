'use client';
import { useEffect, useRef, useState } from 'react';

// true bila layar sentuh masih portrait (orientation lock ditolak / rotasi otomatis HP mati).
// Komponen yang memakainya memutar tampilannya 90° lewat CSS (class .rot) supaya tetap terlihat landscape.
// rotRef dipakai handler sentuh (di luar render React) untuk mengonversi koordinat.
export function useForceLandscape() {
  const [rot, setRot] = useState(false);
  const rotRef = useRef(false);
  useEffect(() => {
    let t: ReturnType<typeof setTimeout> | null = null;
    const check = () => {
      const v = window.innerHeight > window.innerWidth && window.matchMedia('(pointer:coarse)').matches;
      if (v === rotRef.current) return;
      rotRef.current = v; setRot(v);
    };
    // debounce singkat: saat lock landscape sedang diproses browser, layar sempat portrait sesaat (jangan berkedip memutar)
    const onChange = () => { if (t) clearTimeout(t); t = setTimeout(check, 250); };
    t = setTimeout(check, 250);
    window.addEventListener('resize', onChange); window.addEventListener('orientationchange', onChange);
    return () => { if (t) clearTimeout(t); window.removeEventListener('resize', onChange); window.removeEventListener('orientationchange', onChange); };
  }, []);
  return { rot, rotRef };
}
