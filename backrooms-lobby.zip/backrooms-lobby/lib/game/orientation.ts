// Landscape lock untuk gameplay mobile. Semua best-effort: bila browser/device menolak,
// game tetap jalan (PlayScene menampilkan petunjuk "putar ponsel" lewat CSS saat portrait).
// Tidak ada rotasi manual kamera/UI di sini.
type LockableOrientation = ScreenOrientation & { lock?: (o: 'landscape') => Promise<void> };

const orient = (): LockableOrientation | null =>
  typeof screen !== 'undefined' ? ((screen.orientation as LockableOrientation | undefined) ?? null) : null;

const tryLock = async (): Promise<boolean> => {
  try { const o = orient(); if (!o || !o.lock) return false; await o.lock('landscape'); return true; } catch { return false; }
};

// Panggil langsung dari user gesture (klik Play) dengan fullscreen=true.
// Urutan: coba lock langsung (PWA / browser yang mengizinkan) -> bila ditolak, fullscreen lalu lock lagi.
export async function lockLandscape(fullscreen: boolean): Promise<void> {
  if (typeof document === 'undefined') return;
  if (await tryLock()) return;
  if (!fullscreen) return;
  try {
    const el = document.documentElement;
    if (!document.fullscreenElement && el.requestFullscreen) await el.requestFullscreen({ navigationUI: 'hide' });
  } catch { /* fullscreen ditolak: lanjut tanpa */ }
  await tryLock();
}

export function unlockLandscape(): void {
  try { orient()?.unlock?.(); } catch { /* abaikan */ }
  try { if (typeof document !== 'undefined' && document.fullscreenElement) void document.exitFullscreen().catch(() => {}); } catch { /* abaikan */ }
}
